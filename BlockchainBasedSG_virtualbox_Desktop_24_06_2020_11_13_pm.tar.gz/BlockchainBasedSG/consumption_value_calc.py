
# -*- coding: utf-8 -*-
# """
# Created on Thu Jun 18 18:25:36 2020

# @author: mdtamjidhossain
# """


import json 
import sys
import os
import pandas as pd
import numpy as np

def main(arg0,arg1):
    print(str(arg1))
    
    ini_list = str(arg1)
            
    
    res = json.loads(ini_list)
    
    
    
    measurement_index_list = []
    measurement_values_list = []
    
    for nodes in res:
        for i in range(len(nodes)):
            try:
                measurement_index_list.append(nodes[2*i])
                measurement_values_list.append(nodes[2*i+1])
                
            except:
                continue
    
    
    df_measurement = pd.DataFrame()
    df_measurement['index'] =  measurement_index_list
    df_measurement['values'] =  measurement_values_list
    
    final_df_measurement = df_measurement.sort_values(['index'], ascending=True)
    final_df_measurement = final_df_measurement.reset_index(drop = True)
    final_df_measurement['consumption_type'] = final_df_measurement.apply(lambda row: 'Vm' if(row['index']%10 == 1) else ('Vp' if (row['index']%10 == 2) else ( 'P' if (row['index']%10 == 3) else ('Q' if(row['index']%10 == 4) else '' ))), axis = 1)
    
    final_df_measurement_pivot = pd.DataFrame()
    final_df_measurement_pivot = pd.pivot_table(final_df_measurement, index = ['consumption_type'], values = ['values'], aggfunc = np.mean)
    final_df_measurement_pivot = final_df_measurement_pivot.reset_index()
    
    consumption_type_list = []
    values_list = []
    consumption_val_list = []
    final_consumption_val_list = []
    
    consumption_type_list = final_df_measurement_pivot['consumption_type'].to_list()
    values_list = final_df_measurement_pivot['values'].to_list()
    
    for i in range(len(consumption_type_list)):
        consumption_val_list.append(consumption_type_list[i])
        consumption_val_list.append(round(values_list[i],3))
        final_consumption_val_list.append(consumption_val_list)
        consumption_val_list = []
        
    consumption_val_list_string = ""
    consumption_val_list_string = str(final_consumption_val_list)
    print(consumption_val_list_string)
    

if __name__ == "__main__":
    main(sys.argv[0], sys.argv[1])
    
    











    
    
    