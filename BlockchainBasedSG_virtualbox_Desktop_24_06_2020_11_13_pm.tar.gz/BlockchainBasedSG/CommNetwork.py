#!/usr/bin/python
 
 
from mininet.net import Mininet
from mininet.node import Controller, OVSController, RemoteController, OVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel
from mininet.topo import Topo
import os
import os.path

#from pox import POX
 
if __name__ == '__main__':
 

  setLogLevel('info')

  net = Mininet(controller=Controller, switch=OVSSwitch )
  c1 = net.addController( 'c1', controller=Controller)
  
  ## added two switches
  s1 = net.addSwitch("s1", mac = 11) 
  s2 = net.addSwitch("s2", mac = 12) 
  cc = net.addHost('CC', ip='10.0.0.1')  ## add a host representing ControlCenter
  r1 = net.addHost('Relay1', ip='10.0.0.11')
  r2 = net.addHost('Relay2', ip='10.0.0.12')
  r3 = net.addHost('Relay3', ip='10.0.0.13')
  r4 = net.addHost('Relay4', ip='10.0.0.14')
  da = net.addHost('DA', ip='10.0.0.20')  ## add a host representing DataAggregator
 
  net.addLink('s1', 's2')
  net.addLink('s1', cc)
  net.addLink('s2', r1)
  net.addLink('s2', r2)
  net.addLink('s2', r3)
  net.addLink('s2', r4)
  net.addLink('s2', da)
  '''
  runCmd = 'outstationdemo 1 > /home/onos/RaincoatDemo/log/m1-std.txt 2> /home/onos/RaincoatDemo/log/m1-err.txt &'
  pid = m1.cmd(runCmd) 
  runCmd = 'outstationdemo 2 > /home/onos/RaincoatDemo/log/m2-std.txt 2> /home/onos/RaincoatDemo/log/m2-err.txt &' 
  pid = m2.cmd(runCmd) 
  runCmd = 'outstationdemo 3 > /home/onos/RaincoatDemo/log/m3-std.txt 2> /home/onos/RaincoatDemo/log/m3-err.txt &' 
  pid = m3.cmd(runCmd) 
  runCmd = 'outstationdemo 4 > /home/onos/RaincoatDemo/log/m4-std.txt 2> /home/onos/RaincoatDemo/log/m4-err.txt &' 
  pid = m4.cmd(runCmd) 
  runCmd = 'outstationdemo 5 > /home/onos/RaincoatDemo/log/m5-std.txt 2> /home/onos/RaincoatDemo/log/m5-err.txt &' 
  pid = m5.cmd(runCmd) 
  '''
    
  net.build()
  net.start()
  CLI(net) 
 
  net.stop()
