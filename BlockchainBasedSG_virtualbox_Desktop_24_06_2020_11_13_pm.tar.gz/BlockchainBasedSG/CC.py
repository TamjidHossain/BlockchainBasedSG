# -*- coding: utf-8 -*-
"""
Created on Wed Feb 12 16:19:28 2020

@author: lab-user
"""

import struct as st
import socket
import zipfile
import time
import json
#%%


cc_req_indices = []

#for n in range(1,10):
#    for p in range(1,5):
#        indices_count = 10*n+p
#        cc_req_indices.append(indices_count)

cc_req_indices = [11,12,13,14,21,22,23,24,31,32,33,34,41,42,43,44,51,52,53,54,61,62,63,64,71,72,73,74,81,82,83,84,91,92,93,94]
#cc_req_indices = [11,13,31,33,54,93,91,32]

node_indices_dict = dict()        
#node_indices_dict = {'R1':cc_req_indices[0:8],
#                   'R2':cc_req_indices[8:16],
#                   'R3':cc_req_indices[16:24],
#                   'R4':cc_req_indices[24:36]}

node_indices_dict = {'R1': [11, 12, 13, 14, 21, 22, 23, 24],
                   'R2': [31, 32, 33, 34, 41, 42, 43, 44],
                   'R3': [51, 52, 53, 54, 61, 62, 63, 64],
                   'R4': [71, 72, 73, 74, 81, 82, 83, 84, 91, 92, 93, 94]}

index_value_dict = dict()
index_value_dict = {11:1.0, 12:0.0, 13:71.95, 14:24.07, 21:1.0, 22:9.67, 23:163.0, 24:14.46,
                    31:1.0, 32:4.77, 33:85.0, 34:-3.65, 41:0.99, 42:-2.41, 43:0.0, 44:0.0,
                    51:0.98, 52:-4.02, 53:-90.0, 54:-30.0, 61:1.01, 62:1.93, 63:0.0, 64:0.0, 
                    71:0.99, 72:0.62, 73:-100, 74:-35.0, 81:1.0, 82:3.80, 83:0.0, 84:0.0,
                    91:0.96, 92:-4.35, 93:0.0, 94:0.0}

#%%

# CC pack the req, sends it to DA and acts as a client
cc_req = 1
cc_req_len = int(len(cc_req_indices))+2

cc_req_format = '<BB{}B'.format(len(cc_req_indices))
cc_req_pack = st.pack(cc_req_format,cc_req,cc_req_len,*cc_req_indices)

remote_host = '10.0.0.20'
remote_port = 20000
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((remote_host, remote_port))
count = 1

while True:
    # request starts here
    s.sendall(cc_req_pack)
    
    data = s.recv(1024)


    feedback_from_DA = str(data.decode('utf-8'))

    if("Verified Blockchain = " in feedback_from_DA):
            
            # blockchain copy from DA
            blockchain_DA = []
            blockchain_DA = feedback_from_DA.split("=")
            dataPack4 = blockchain_DA[1].strip(" ")
            dataPack4 = dataPack4.replace("'", '"')
            res4 = json.loads(dataPack4)
            
            ## Own blockchain copy
            blockchain_file1 = open("/home/user/Desktop/BlockchainBasedSG/blockchain_CC.txt","r")
            blockchain_file_data1 = blockchain_file1.read()
            dataPack5 = str(blockchain_file_data1)
            dataPack5 = dataPack5.replace("'", '"')
            res5 = json.loads(dataPack5)            ##res5 is for R1
            

            
            res5.append(res4[-1])
            
            text_file = open('/home/user/Desktop/BlockchainBasedSG/blockchain_CC.txt', "wt")
            n = text_file.write(str(res5))
            text_file.close()
            
            if (len(res5) > 10):
            # if(res5[-1]['index'] % 10 == 0):
                # filename_index = res5[-1]['index'] % 9
                filename_index = str(res5[-1]['index'])[0:-1]
                filename = "/home/user/Desktop/BlockchainBasedSG/blockchain"+ str(filename_index)+"_CC.zip"
                file_zip = zipfile.ZipFile(filename, 'w')
                file_zip.write('/home/user/Desktop/BlockchainBasedSG/blockchain_CC.txt', compress_type=zipfile.ZIP_DEFLATED)
                file_zip.close()
                
                res12 = []
                res12.append(res5[-1])
                text_file = open('/home/user/Desktop/BlockchainBasedSG/blockchain_CC.txt', "wt")
                n = text_file.write(str(res12))
                text_file.close()
            
            if n != 0:
                update_chain_feedback = "chain updated"
                print("Count - " + str(count) + " Chain Update Feedback - "+ str(update_chain_feedback))
            

    time.sleep(5)
    count = count+1    


