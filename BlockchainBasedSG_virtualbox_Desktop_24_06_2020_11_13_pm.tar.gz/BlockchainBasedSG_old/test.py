#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 18:33:26 2020

@author: mdtamjidhossain
"""

import os
import sys
import subprocess

relay_resp_unpack_indices_nested_list = '[[1.0, 2], 3, 4, 5]'

dataPack = str(relay_resp_unpack_indices_nested_list)

# cmdstring = "/home/user/Desktop/BlockchainBasedSG/selectMiningNode.py %s" % dataPack

# miningNode = os.system(cmdstring)

# print(miningNode)


miningNodeSelect_script = "/home/user/Desktop/BlockchainBasedSG/selectMiningNode.py"
miningNode = subprocess.check_output([sys.executable, 
                              miningNodeSelect_script,
                              dataPack])
miningNode = miningNode.decode("utf-8")

print(miningNode)
