#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 00:58:09 2020

@author: mdtamjidhossain
"""

#%%
import hashlib

import json

import time

import os

import sys

from time import time


blockchain_text_dir = "/home/user/Desktop/BlockchainBasedSG/"

reward = 10.0

# genesis_time = time()

# genesis_block = {

#     'previous_hash': '',

#     'index': 0,
    
#     'timestamp': genesis_time,
   
#     'current_hash': '',

#     'consumption_value': [],

#     'nonce': 23

# }

# blockchain = [genesis_block]


arg1 = str(sys.argv[1])
    
arg1 = arg1.replace("'", '"')

res = json.loads(arg1)


consumption_data = res[0][1]

owner = res[1][1]

recipient = res[2][1]

open_consumption_values = []

blockchain_text_file = blockchain_text_dir + "blockchain_" + str(owner) + ".txt"


blockchain_file = open(blockchain_text_file,"r")
blockchain_file_data = blockchain_file.read()
dataPack2 = str(blockchain_file_data)
dataPack2 = dataPack2.replace("'", '"')
res2 = json.loads(dataPack2)

blockchain = res2

blockchain_file.close()

#%%

def hash_prev_block(block):

    return hashlib.sha256(json.dumps(block).encode()).hexdigest()


#%%
   
def valid_proof(consumption_values, last_hash, nonce):

    guess = (str(consumption_values) + str(last_hash) + str(nonce)).encode()

    guess_hash = hashlib.sha256(guess).hexdigest()

    # print(guess_hash)

    return guess_hash[0:2] == '00'



def pow():

    last_block = blockchain[-1]

    last_hash = hash_prev_block(last_block)

    nonce = 0

    while not valid_proof(open_consumption_values, last_hash, nonce):

        nonce += 1

    return nonce

#%%
   
def get_last_value():

    """ extracting the last element of the blockchain list """

    return(blockchain[-1])



def add_value(recipient, sender=owner, consumption_data=1.0):

    consumption_value = {'sender': sender,

    'recipient': recipient,

    'consumption_data': consumption_data}

    open_consumption_values.append(consumption_value)
   
#%%
   
def mine_block():
   
    mining_time = time() 

    last_block = blockchain[-1]

    prev_hash = last_block['current_hash']

    nonce = pow()

    reward_consumption_value = {

            'sender': 'CC',

            'recipient': owner,

            'reward': reward

        }

    open_consumption_values.append(reward_consumption_value)
   
    block_without_current_hash = {

        'previous_hash': prev_hash,

        'index': len(blockchain),
       
        'timestamp': mining_time,

        'consumption_value': open_consumption_values,

        'nonce': nonce

    }
   
    curr_hash = hash_prev_block(block_without_current_hash)

    block = {

        'previous_hash': prev_hash,

        'index': len(blockchain),
       
        'timestamp': mining_time,
       
        'current_hash': curr_hash,

        'consumption_value': open_consumption_values,

        'nonce': nonce

    }

    blockchain.append(block)
    
    msg = "mining done"
    
    return msg
   
#%%
   
# def get_consumption_value():

#     tx_recipient = input('Enter the recipient of the consumption_value: ')

#     tx_consumption_data = float(input('Enter your consumption_value'))

#     return tx_recipient, tx_consumption_data



# def get_user_choice():

#     user_input = input("Please give your choice here: ")

#     return user_input

#%%
   
def print_block():

    for block in blockchain:

        print("Here is your block")

        print(block)
       
#%%
       
def verify_chain():

    index = 0

    valid = True

    for block in blockchain:
        if index == 0:

            index += 1

            continue

        elif block['previous_hash'] == blockchain[index - 1]['current_hash']:

            valid = True

        else:

            valid = False

            break

        index += 1

    return valid


#%%
    

add_value(recipient, consumption_data=consumption_data)

# mine_block()

if(mine_block() == "mining done"):
    output = "New block successfully added to the blockchain"

else:
    output = "Block Mining unsuccessful|"

if not verify_chain():
    
    if len(blockchain) > 2:
        
        manipulation_text_file = open("/home/user/Desktop/BlockchainBasedSG/blockchain_manipulation_attempt.txt", "wt")
        
        n = manipulation_text_file.write("Blockchain Manipulation Attempt found by "+ str(owner) + " at Epoch time: " + str(time()))
        
        manipulation_text_file.close()
        
        output = output + " but verification has not been carried out due to only 2 blocks available|"
    
    
    else:
        
        text_file = open(blockchain_text_file, "wt")
        
        n = text_file.write("Blockchain Manipulated|")
        
        text_file.close()

else:
    
    text_file = open(blockchain_text_file, "wt")
        
    n = text_file.write(str(blockchain))
    
    text_file.close()
    
    output = output + " and verification also successful|"

if ((output == "New block successfully added to the blockchain and verification also successful|") | (output == "New block successfully added to the blockchain but verification has not been carried out due to only 2 blocks available|")):
    
    final_output = output + "Updated Blockchain = " + str(blockchain[-2:])
    
    print(final_output)
    
else:
    print(output)




#%%
       
# while True:

   # print("Choose an option")

   # print('Choose 1 for adding a new consumption_value')

   # print('Choose 2 for mining a new block')

   # print('Choose 3 for printing the blockchain')

   # print('Choose anything else if you want to quit')

   # print('Choose 0 if you want to manipulate the data')
   
   # user_choice = get_user_choice()
    
# user_choice = sys.argv[1]

# menuChoice = ""




# if len(user_choice) < 1:
#     print('No user input')
# else:
#     pass
    
# if len(user_choice) > 1:
    
#     if len(user_choice) == 6:
        
#         tx_recipient = user_choice[1:4]
        
#         tx_amount = user_choice[4:6]
        
#         print(blockchain)
    
#     else:
        
#         print("Invalid user Iinput")
        
# else:    
#     menuChoice = user_choice[0:1]

    

# if menuChoice == '1':

#     # tx_data = get_consumption_value_value()

#     # recipient, amount = tx_data
    
#     recipient = tx_recipient
    
#     amount = tx_amount

#     add_value(recipient, amount=amount)

#     print(open_consumption_values)



# elif menuChoice == '2':

#     mine_block()



# elif menuChoice == '3':

#     print_block()

# elif menuChoice == '0':
 
#     if len(blockchain) >= 1:
 
#         blockchain[1] = {'previous_hash': '', 'index': 0, 'timestamp': 1592398765.169802, 'current_hash': '', 'consumption_value': [5], 'nonce': 23}

# else:
    
#     pass

# if not verify_chain():
    
#     print('Blockchain manipulated')
    
#     pass
   
#%%



# def main(arg0, arg1):
    
#     arg1 = str(arg1)
    
#     arg1 = arg1.replace("'", '"')
    
#     res = json.loads(arg1)
    
    
#     amount = res[0]
    
#     recipient = res[2]
    
#     owner = res[0]

#     add_value(recipient, amount=amount)
    
#     mine_block()
    
#     text_file = open("/home/user/Desktop/BlockchainBasedSG/blockchain.txt", "wt")
    
#     n = text_file.write(str(blockchain))
    
#     text_file.close()

#     # print(open_transactions)

# if __name__ == "__main__":
#     main(sys.argv[0], sys.argv[1])
    
 #%%
    
# a = "[['consumption_data', [['P', 14.439], ['Q', -3.347], ['Vm', 0.992], ['Vp', 1.112]]], ['owner', 'R2'], ['recipient', 'CC']]"    

# a = a.replace("'", '"')
    
# res = json.loads(a)   

# consumption_list = res[0]

# owner_list = res[1]

# recipient_list = res[2]

# print(recipient_list)


    
    
    
    
    
    
    
    
    
    
    
    
    

